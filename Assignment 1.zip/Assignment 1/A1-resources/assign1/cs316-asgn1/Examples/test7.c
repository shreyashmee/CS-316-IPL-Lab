void f();

f(){
  int a_9;
  int a_8;

  a_9 = 0;
}