void main();

main(){
  int a_331d;
  int a_9;

  a_331d=10;
  a_331d=900;
  a_331d=10;
  a_9_f= 0;
  a_9 = 0;
  a_9_f = 1;
}