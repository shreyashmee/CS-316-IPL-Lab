void main();

main(){
  int a_9;

  a_9 = +878;
}