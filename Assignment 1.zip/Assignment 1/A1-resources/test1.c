
int c,d,e,f;
void main()
{
	int a,b;

	a=2;
	b=3;

	c=a+b;
    d=a-b;
    e=a*b;
    f=a/b;
}

